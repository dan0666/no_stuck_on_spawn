fx_version 'cerulean'
game 'gta5'
author 'International systems'
description 'On ground'
version '1.0'
lua54 'yes'


client_script "client.lua"

escrow_ignore {
             "client.lua"
}